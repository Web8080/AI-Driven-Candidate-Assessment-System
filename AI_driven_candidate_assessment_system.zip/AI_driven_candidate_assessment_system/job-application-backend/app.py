from flask import Flask, request, jsonify
import os

app = Flask(__name__)

# Create uploads directory if it doesn't exist
if not os.path.exists('uploads'):
    os.makedirs('uploads')

@app.route('/submit', methods=['POST'])
def submit_assessment():
    if 'resume' not in request.files:
        return jsonify({"status": "fail", "message": "No file part"}), 400
    
    file = request.files['resume']
    
    if file.filename == '':
        return jsonify({"status": "fail", "message": "No selected file"}), 400
    
    # Save the file to the uploads directory
    file_path = os.path.join('uploads', file.filename)
    file.save(file_path)

    return jsonify({"status": "success"}), 200

if __name__ == "__main__":
    app.run(debug=True)
