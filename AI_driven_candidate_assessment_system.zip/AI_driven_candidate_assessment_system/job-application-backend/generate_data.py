import pandas as pd
import random

# Define synthetic data
data = {
    'name': [],
    'email': [],
    'responses': [],
    'score': []
}

for i in range(100):  # Generate 100 samples
    name = f"User {i + 1}"
    email = f"user{i + 1}@example.com"
    responses = [random.randint(0, 1) for _ in range(4)]  # 4 questions, binary answers
    score = random.randint(50, 100)  # Random score between 50 and 100

    data['name'].append(name)
    data['email'].append(email)
    data['responses'].append(responses)
    data['score'].append(score)

# Create a DataFrame
df = pd.DataFrame(data)

# Save to CSV
df.to_csv('synthetic_assessment_data.csv', index=False)
