const express = require('express');
const multer = require('multer');
const { exec } = require('child_process');
const path = require('path');
const { Client } = require('pg');
const app = express();

// PostgreSQL setup
const client = new Client({
  user: 'postgres',
  host: '127.0.0.1',
  database: 'candidate_assessment',
  password: 'NTU99999@',
  port: 5432,
});

client.connect((err) => {
  if (err) {
    console.error('Failed to connect to PostgreSQL:', err);
  } else {
    console.log('Connected to PostgreSQL');
  }
});

// Serve static frontend files
app.use(express.static(path.join(__dirname, '../frontend')));

// Middleware for form and file upload
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Multer configuration for file upload
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, 'uploads'));
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  },
});
const upload = multer({ storage: storage });

// Handle form submission and file upload
app.post('/submit', upload.single('resume'), (req, res) => {
  const { name, details, responses } = req.body;
  const resumePath = req.file.path;

  console.log('Received form submission:', name, details, responses, resumePath);

  // Save data to PostgreSQL
  const query = `
    INSERT INTO candidates (name, details, resume_path, responses, extracted_skills)
    VALUES ($1, $2, $3, $4, $5)
    RETURNING *;
  `;

  // Run Python script to process resume and form data
  exec(`python3 evaluate_assessment.py ${resumePath} '${JSON.stringify(responses)}'`, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error: ${error}`);
      return res.status(500).send('Error analyzing the data.');
    }

    console.log('Python stdout:', stdout);
    console.log('Python stderr:', stderr);

    if (!stdout) {
      return res.status(500).send('No output received from the Python script.');
    }

    try {
      const result = JSON.parse(stdout); // Parse the JSON output
      const matchedSkills = result.matched_skills.join(', ');  // Join matched skills into a string for storage

      const values = [name, details, resumePath, responses, matchedSkills];  // Store only matched skills

      client.query(query, values, (err, dbResult) => {
        if (err) {
          console.error('Error saving to database:', err);
          return res.status(500).send('Error saving data to the database.');
        }

        console.log('Data saved to database:', dbResult.rows[0]);
        res.json(dbResult.rows[0]);
      });
    } catch (parseError) {
      console.error('Error parsing JSON:', parseError);
      res.status(500).send('Error processing the results.');
    }
  });
});


// Serve index.html by default
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend', 'index.html'));
});

// Start the server
app.listen(3000, () => {
  console.log('Server running on port 3000');
});
