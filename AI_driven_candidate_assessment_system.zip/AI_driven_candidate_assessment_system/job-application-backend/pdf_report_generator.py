from fpdf import FPDF

def generate_pdf_report(data, output_path):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    pdf.cell(200, 10, txt="Candidate Assessment Report", ln=True, align='C')
    pdf.ln(10)

    pdf.cell(200, 10, txt="Skills extracted from CV:", ln=True)
    for skill in data['skills']:
        pdf.cell(200, 10, txt=f"- {skill}", ln=True)

    pdf.ln(10)
    pdf.cell(200, 10, txt=f"Score: {data['score']}/5", ln=True)

    pdf.output(output_path)
