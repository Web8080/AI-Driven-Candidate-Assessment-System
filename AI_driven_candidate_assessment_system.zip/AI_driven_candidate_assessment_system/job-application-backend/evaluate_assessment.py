import sys
import json
import PyPDF2
import spacy
from pdf_report_generator import generate_pdf_report

# Load spaCy for resume parsing
nlp = spacy.load("en_core_web_sm")

# Function to extract custom keywords from the job description file
def load_job_keywords(file_path):
    job_keywords = []
    with open(file_path, 'r') as file:
        for line in file:
            job_keywords.append(line.strip().lower())
    return job_keywords

# Function to extract text from the uploaded PDF resume
def extract_text_from_cv(cv_path):
    try:
        with open(cv_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            text = ""
            for page in range(len(reader.pages)):
                text += reader.pages[page].extract_text()
        return text
    except Exception as e:
        print(f"Error extracting text from PDF: {e}", file=sys.stderr)
        return ""

# Function to extract key skills and qualifications using spaCy
def extract_skills_and_experience_from_resume(resume_text):
    doc = nlp(resume_text)
    skills = set()
    for token in doc:
        if token.pos_ in ["NOUN", "PROPN"]:
            skills.add(token.text.lower())
    return skills

# Function to score based on the number of matched skills
def score_candidate_skills(candidate_skills, job_keywords):
    matched_skills = [skill for skill in candidate_skills if skill in job_keywords]
    match_score = len(matched_skills)
    return match_score, matched_skills

# Main function to process the resume and calculate the score
def main():
    try:
        cv_path = sys.argv[1]
        responses = json.loads(sys.argv[2])

        # Extract text from resume
        resume_text = extract_text_from_cv(cv_path)

        # Extract skills from resume
        candidate_skills = extract_skills_and_experience_from_resume(resume_text)

        # Load job keywords
        job_keywords = load_job_keywords('job_keywords.txt')

        # Filter to only matched skills
        score, matched_skills = score_candidate_skills(candidate_skills, job_keywords)

        result = {
            'matched_skills': matched_skills  # Only return matched skills
        }

        # Output result as JSON
        print(json.dumps(result))

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)

if __name__ == "__main__":
    main()
