document.getElementById('applicationForm').addEventListener('submit', async (event) => {
    event.preventDefault();  // Prevent default form submission
  
    const formData = new FormData();
    formData.append('name', document.getElementById('name').value);
    formData.append('details', document.getElementById('details').value);
    formData.append('resume', document.getElementById('resume').files[0]);
    formData.append('responses', JSON.stringify([
      document.getElementById('question1').value,
      document.getElementById('question2').value,
      document.getElementById('question3').value,
      document.getElementById('question4').value,
      document.getElementById('question5').value,
    ]));
  
    try {
      const response = await fetch('/submit', {
        method: 'POST',
        body: formData,
      });
  
      if (!response.ok) {
        throw new Error(`Server error: ${response.status} - ${response.statusText}`);
      }
  
      // Redirect to a "Thank You" page after successful submission
      window.location.href = '/thank-you.html';
    } catch (error) {
      console.error('Error submitting form:', error);
      alert(`Failed to submit the form. Please try again. Error details: ${error.message}`);
    }
  });
  